let config = {
    host    : 'localhost',
    user    : 'nodeuser',
    password: 'nodeuser@1234',
    database: 'mdb',
    port: 3306
  };
  
  module.exports = config;
  //TempLogin1!